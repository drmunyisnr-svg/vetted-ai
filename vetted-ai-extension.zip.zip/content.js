function captureTelemetry() {
    // 1. Automatically find the price on the webpage
    let priceElement = document.querySelector('[data-price]') || 
                       document.querySelector('.price') || 
                       document.querySelector('.current-price') ||
                       document.querySelector('[class*="price"]');
    
    let riskFactor = 0;

    if (priceElement) {
        // Strip out non-numeric characters like "KSh" or commas
        let rawPriceText = (priceElement.innerText || priceElement.textContent || '').replace(/[^0-9.]/g, '');
        let numericPrice = parseFloat(rawPriceText);
        
        if (!isNaN(numericPrice) && numericPrice > 0) {
            // Generate a random mock risk threshold between 15% and 45% for testing
            riskFactor = Math.floor(Math.random() * (45 - 15 + 1)) + 15;
        }
    } else {
        // Default fallback mock risk factor if a price tag isn't explicitly found
        riskFactor = 23; 
    }

    // 2. CRITICAL STEP: Ping background.js to increment the count by +1
    chrome.runtime.sendMessage({ 
        action: "logTrafficEvent", 
        riskValue: riskFactor 
    }, (response) => {
        if (chrome.runtime.lastError) {
            console.error("Telemetry dispatch failed:", chrome.runtime.lastError.message);
            return;
        }
        if (!response || response.status !== "success") {
            console.error("Telemetry was not recorded:", response && response.message);
            return;
        }
        console.log("Telemetry dispatched successfully.", response.count);
    });
}

// Execute the tracker script exactly 1.5 seconds after the web page loads
setTimeout(captureTelemetry, 1500);
