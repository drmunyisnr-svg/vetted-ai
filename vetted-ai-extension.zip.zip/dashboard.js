const trafficValue = document.getElementById('log-traffic');
const riskValue = document.getElementById('log-risk');

function getLoggedData(callback) {
  chrome.storage.local.get(['globalTrafficCount', 'maxScamDelta'], (result) => {
    if (chrome.runtime.lastError) {
      const errorMessage = chrome.runtime.lastError.message;
      console.error('Unable to read telemetry data:', errorMessage);
      return;
    }
    callback(result);
  });
}

function loadLoggedData() {
  getLoggedData((result) => {
    trafficValue.textContent = result.globalTrafficCount || 0;
    riskValue.textContent = `${Math.round(result.maxScamDelta || 0)}%`;
  });
}

function downloadTrafficLedger() {
  getLoggedData((result) => {
    const totalViews = result.globalTrafficCount || 0;
    const maxRisk = Math.round(result.maxScamDelta || 0);
    const localTimestamp = new Date().toLocaleString();
    const ledgerContent = `=========================================
VETTED AI ENGINE - LOCAL TRAFFIC LEDGER
Generated On: ${localTimestamp}
=========================================
[✓] TOTAL PAGE IMPRESSIONS LOGGED : ${totalViews} views
[✓] HIGHEST MARKET INFLATION FLAG  : ${maxRisk}% Risk

-----------------------------------------
End of System Telemetry Report.
`;

    const blob = new Blob([ledgerContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = url;
    downloadAnchor.download = `vetted_traffic_ledger_${Date.now()}.txt`;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
}

document.getElementById('sync-btn').addEventListener('click', loadLoggedData);
document.getElementById('export-btn').addEventListener('click', downloadTrafficLedger);
loadLoggedData();
