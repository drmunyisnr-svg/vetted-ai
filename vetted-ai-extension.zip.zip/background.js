chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['globalTrafficCount', 'maxScamDelta'], (db) => {
    if (chrome.runtime.lastError) {
      console.error('Unable to initialize telemetry storage:', chrome.runtime.lastError.message);
      return;
    }

    const initialValues = {};
    if (!Number.isSafeInteger(db.globalTrafficCount) || db.globalTrafficCount < 0) {
      initialValues.globalTrafficCount = 0;
    }
    if (typeof db.maxScamDelta !== 'number' || !Number.isFinite(db.maxScamDelta) || db.maxScamDelta < 0) {
      initialValues.maxScamDelta = 0;
    }

    if (Object.keys(initialValues).length > 0) {
      chrome.storage.local.set(initialValues, () => {
        if (chrome.runtime.lastError) {
          console.error('Unable to initialize telemetry storage:', chrome.runtime.lastError.message);
        }
      });
    }
  });
});

let updateQueue = Promise.resolve();

function recordTrafficEvent(riskValue) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(['globalTrafficCount', 'maxScamDelta'], (db) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      const currentTraffic = Number.isSafeInteger(db.globalTrafficCount) && db.globalTrafficCount >= 0
        ? db.globalTrafficCount
        : 0;
      const existingMaxRisk = typeof db.maxScamDelta === 'number' &&
        Number.isFinite(db.maxScamDelta) && db.maxScamDelta >= 0
        ? db.maxScamDelta
        : 0;
      const newTrafficTotal = currentTraffic + 1;
      const newMaxRisk = Math.max(existingMaxRisk, riskValue);

      chrome.storage.local.set({
        globalTrafficCount: newTrafficTotal,
        maxScamDelta: newMaxRisk
      }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(newTrafficTotal);
      });
    });
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== 'object' || message.action !== 'logTrafficEvent') {
    return false;
  }

  if (typeof message.riskValue !== 'number' ||
      !Number.isFinite(message.riskValue) ||
      message.riskValue < 0) {
    sendResponse({ status: 'error', message: 'Invalid risk value.' });
    return false;
  }

  const operation = updateQueue.then(() => recordTrafficEvent(message.riskValue));
  updateQueue = operation.catch((error) => {
    console.error('Unable to record telemetry event:', error);
  });

  operation.then(
    (count) => sendResponse({ status: 'success', count }),
    (error) => sendResponse({ status: 'error', message: error.message })
  );
  return true;
});
