/**
 * VETTED AI ENGINE - Real-Time Automation UI Overlay Script
 * Universal DOM Injection Engine for Marketplaces
 */

(function() {
    // Prevent multiple parallel script execution layers on a single tab
    if (document.getElementById('vetted-ai-root')) return;

    // Configuration Benchmarks (Simulated baseline targets)
    const MARKET_BENCHMARKS = {
        "dispenser": 4200,
        "iphone": 22000,
        "solar": 14000,
        "battery": 18000,
        "default": 3500
    };

    // Tracking tags for your global earning streams
    const REVENUE_KEYS = {
        JUMIA_KOL_ID: "YOUR_REAL_JUMIA_KOL_ID_HERE",
        AMAZON_TAG: "YOUR_AMAZON_TRACKING_TAG"
    };

    function runMarketplaceAnalysis() {
        const itemTitle = getProductTitle();
        const itemPrice = getProductPrice();

        if (itemPrice > 0) {
            const baselinePrice = determineBaseline(itemTitle, itemPrice);
            const inflationDelta = ((itemPrice - baselinePrice) / baselinePrice) * 100;
            const isOverpriced = inflationDelta > 15;

            injectOverlayUI(itemTitle, itemPrice, inflationDelta, isOverpriced);
            dispatchTelemetry(inflationDelta);
        }
    }

    // Scrapes product headers by searching standard marketplace DOM classes
    function getProductTitle() {
        const selectors = ['h1', '.title', '#productTitle', '.pname', '.fn'];
        for (const selector of selectors) {
            const element = document.querySelector(selector);
            const title = element && (element.innerText || element.textContent);
            if (title && title.trim().length > 0) {
                return title.trim();
            }
        }
        return document.title || "Marketplace Asset";
    }

    // Strips currency symbols and characters to extract a clean floating-point price
    function getProductPrice() {
        const selectors = [
            '[data-price]',
            '.price',
            '#priceblock_ourprice',
            '.a-price-whole',
            '.current-price',
            '.prc'
        ];
        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                const priceText = element.getAttribute('data-price') ||
                    element.innerText ||
                    element.textContent ||
                    '';
                const numericString = priceText.replace(/[^0-9.]/g, '');
                const parsedPrice = parseFloat(numericString);
                if (!isNaN(parsedPrice) && parsedPrice > 0) return parsedPrice;
            }
        }
        return 0;
    }

    // Evaluates appropriate baseline estimates based on semantic keywords
    function determineBaseline(title, price) {
        const lowerTitle = title.toLowerCase();
        for (const key in MARKET_BENCHMARKS) {
            if (key !== "default" && lowerTitle.includes(key)) {
                return MARKET_BENCHMARKS[key];
            }
        }
        if (MARKET_BENCHMARKS.default) {
            return MARKET_BENCHMARKS.default;
        }
        // General baseline logic fallback if item is entirely unknown
        return price * 0.82;
    }

    function createElement(tagName, styles, text) {
        const element = document.createElement(tagName);
        if (styles) element.style.cssText = styles;
        if (text !== undefined) element.textContent = text;
        return element;
    }

    // Assembles and structures the HTML overlay card natively into the active webpage view
    function injectOverlayUI(title, price, delta, isOverpriced) {
        const overlayRoot = document.createElement('div');
        overlayRoot.id = 'vetted-ai-root';
        overlayRoot.style.cssText = `
            position: fixed; bottom: 20px; right: 20px; z-index: 9999999;
            width: 310px; background: #1c1c1e; border: 1px solid #2c2c2e;
            border-radius: 12px; font-family: monospace; padding: 16px;
            color: #ffffff; box-shadow: 0 12px 36px rgba(0,0,0,0.6);
        `;

        // Routing user links dynamically to trigger automated global affiliate redirects
        const currentDomain = window.location.hostname;
        let affiliateRedirectUrl = `https://www.amazon.com/s?k=${encodeURIComponent(title)}&tag=${encodeURIComponent(REVENUE_KEYS.AMAZON_TAG)}`;

        if (currentDomain.includes('jumia') || currentDomain.includes('.ke')) {
            const jumiaUrl = new URL('/catalog/', `https://${currentDomain}`);
            jumiaUrl.searchParams.set('q', title);
            jumiaUrl.searchParams.set('aff_id', REVENUE_KEYS.JUMIA_KOL_ID);
            jumiaUrl.searchParams.set('sub_id', 'vetted_ext');
            jumiaUrl.searchParams.set('to', window.location.href);
            affiliateRedirectUrl = jumiaUrl.href;
        }

        const header = createElement(
            'div',
            'display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed #2c2c2e; padding-bottom: 8px; margin-bottom: 12px;'
        );
        header.appendChild(createElement(
            'span',
            'font-weight: 900; font-size: 13px; color: #ffffff; letter-spacing: 1px;',
            'VETTED AI v1.0'
        ));

        const closeButton = createElement(
            'button',
            'cursor: pointer; font-size: 14px; color: #8e8e93; font-weight: bold; background: none; border: 0;',
            '✕'
        );
        closeButton.type = 'button';
        closeButton.setAttribute('aria-label', 'Close Vetted AI');
        closeButton.addEventListener('click', () => overlayRoot.remove());
        header.appendChild(closeButton);
        overlayRoot.appendChild(header);

        overlayRoot.appendChild(createElement(
            'div',
            'font-size: 11px; color: #8e8e93; text-transform: uppercase;',
            `Kasongo Risk Index: ${title}`
        ));
        overlayRoot.appendChild(createElement(
            'div',
            `font-size: 18px; font-weight: bold; margin: 4px 0 12px 0; color: ${isOverpriced ? '#ff453a' : '#30d158'};`,
            isOverpriced
                ? `⚠️ INFLATED (+${Math.round(delta)}%)`
                : '✅ FAIR MARKET VALUE'
        ));

        const affiliatePanel = createElement('div');
        affiliatePanel.id = 'vetted-affiliate-match';
        const affiliateLink = createElement(
            'a',
            'display: block; text-align: center; background: #30d158; color: #000000; font-weight: bold; text-decoration: none; padding: 10px; border-radius: 6px; font-size: 12px;',
            '👉 Bypass Scam: Get Vetted Deals'
        );
        affiliateLink.href = affiliateRedirectUrl;
        affiliateLink.target = '_blank';
        affiliateLink.rel = 'noopener noreferrer';
        affiliatePanel.appendChild(affiliateLink);
        overlayRoot.appendChild(affiliatePanel);

        const adSlot = createElement(
            'div',
            'margin-top: 12px; border-top: 1px dashed #2c2c2e; padding-top: 10px; text-align: center;'
        );
        adSlot.id = 'vetted-ad-slot';
        const adTarget = createElement(
            'div',
            'min-height: 45px; font-size: 10px; color: #636366; display: flex; justify-content: center; align-items: center; background: #000000; border: 1px solid #2c2c2e; border-radius: 4px;',
            'Sponsored Telemetry Safe Node'
        );
        adTarget.id = 'native-ad-target';
        adSlot.appendChild(adTarget);
        overlayRoot.appendChild(adSlot);

        document.body.appendChild(overlayRoot);
    }

    // Communicates data updates upstream back into browser database memory loops
    function dispatchTelemetry(riskScore) {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({
                action: "logTrafficEvent",
                riskValue: riskScore
            }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error("Telemetry dispatch failed:", chrome.runtime.lastError.message);
                    return;
                }
                if (!response || response.status !== "success") {
                    console.error("Telemetry was not recorded:", response && response.message);
                }
            });
        }
    }

    // Trigger parsing execution safely following DOM structure paint windows
    if (document.readyState === 'complete') {
        setTimeout(runMarketplaceAnalysis, 1500);
    } else {
        window.addEventListener('load', () => setTimeout(runMarketplaceAnalysis, 1500), { once: true });
    }
})();
